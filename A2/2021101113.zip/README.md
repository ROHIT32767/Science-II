# Assignment-2
# 2021101113
# Science - II
# Gowlapalli Rohit
>##### All these commands are tested on Ubuntu Version 20.04.3 LTS (Focal Fossa) 
```

├── Q1
│   ├── Q1a.py
│   ├── Q1b.py
│   ├── Q1c.py
│   └── Q1.pdf
├── Q2
│   ├── Q2a.py
│   ├── Q2b.py
│   └── Q2.pdf
├── Q3
│   ├── Q3a.py
│   ├── Q3b.py
│   ├── Q3c.py
│   └── Q3.pdf
└── README.md

```
>* Assumptions
1. In Q1b , a new value of A is used to compare with the given value of A inorder to determine randomness of generator
2. Except for Q1b,Q2a , it is expected that none of the other Questions require a theoretical answer
3. For Q2,Q3 it is assumed that the results may vary when compiled each time
4. IN Q3c ,it is assumed that Mean Displacement is considered with sign